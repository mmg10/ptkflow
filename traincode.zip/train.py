
import os
import torch
from pathlib import Path
import pytorch_lightning as pl


from pytorch_lightning import loggers as pl_loggers

from model import LitResnet
from dataset import IntelDataModule


ml_root = Path("/tmp/output")
num_cpus = os.cpu_count()
EPOCHS = 1


def main():
    train_channel = Path("/tmp/test") # to reduce training size :-)
    test_channel = Path("/tmp/test")
    datamodule = IntelDataModule(train_data_dir=train_channel,
                                test_data_dir=test_channel,
                                num_workers=0,
                                batch_size=16)
    datamodule.setup()
    
    
    tb_logger = pl_loggers.TensorBoardLogger(save_dir=ml_root / "tensorboard" )
    
    trainer = pl.Trainer(
        max_epochs=EPOCHS,
        logger=[tb_logger],
        num_sanity_val_steps=0,
        log_every_n_steps=1,
        enable_model_summary=False,
        enable_checkpointing=False,
    )
    model = LitResnet(num_classes=datamodule.num_classes)
    print(":: Training ...")
    trainer.fit(model, datamodule)
    
    print(":: Saving Scripted Model")
    script = model.to_torchscript()
    torch.jit.save(script, Path("/tmp") / "model.pt")


