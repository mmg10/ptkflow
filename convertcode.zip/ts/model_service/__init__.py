
"""
Model services code
"""

from . import model_service
